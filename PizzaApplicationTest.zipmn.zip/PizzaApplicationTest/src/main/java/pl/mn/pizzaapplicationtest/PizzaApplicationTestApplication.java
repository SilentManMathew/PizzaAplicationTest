package pl.mn.pizzaapplicationtest;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PizzaApplicationTestApplication {

    public static void main(String[] args) {
        SpringApplication.run(PizzaApplicationTestApplication.class, args);
    }

}
