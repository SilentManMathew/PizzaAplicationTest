package pl.mn.pizzaapplicationtest.domain.model;

public enum OrderStatusType {

    IN_PROGGRESS, READY, CANCELED, DELIVERED, NEW, OUT_FOR_DELIVERY
}
