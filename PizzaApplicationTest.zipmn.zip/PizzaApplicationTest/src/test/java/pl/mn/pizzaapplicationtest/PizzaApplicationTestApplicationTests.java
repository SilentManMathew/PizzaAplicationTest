package pl.mn.pizzaapplicationtest;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PizzaApplicationTestApplicationTests {

    @Test
    void contextLoads() {
    }

}
