package pl.mn.pizzaapplicationtest.domain.model;

public enum SizeType {
    S,M,L
}
